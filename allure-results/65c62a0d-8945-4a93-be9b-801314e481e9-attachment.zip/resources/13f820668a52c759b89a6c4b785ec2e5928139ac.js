window.autoqlEnv = { BACKEND_URL:"https://backend.chata.io", INTEGRATOR_ID:"none", AUTOAE_URL:"https://autoae-api.chata.io", AUTOAE_KEY:"dpr_1ae16f362e234973bbb86aae1766be73", IS_PORTABLE:"true" };
